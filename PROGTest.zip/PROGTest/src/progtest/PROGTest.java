package progtest;

public class PROGTest {

    public static void main(String[] args) {
        
        //2D array
        int[][] accidentTotals = {
            {155, 121}, // Cape Town
            {178, 145}, // Johannesburg
            {112, 89}   // Port Elizabeth
        };

        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};

        //Display the accident data 
      
        System.out.println("Enter the number of car accidents for Cape Town: " + accidentTotals[0][0]);
        System.out.println("Enter the number of motorbike accidents for Cape Town: " + accidentTotals[0][1]);

        System.out.println("Enter the number of car accidents for Johannesburg: " + accidentTotals[1][0]);
        System.out.println("Enter the number of motorbike accidents for Johannesburg: " + accidentTotals[1][1]);

        System.out.println("Enter the number of car accidents for Port Elizabeth: " + accidentTotals[2][0]);
        System.out.println("Enter the number of motorbike accidents for Port Elizabeth: " + accidentTotals[2][1]);

        //Display overall totals
        int totalCarAccidentsCT = accidentTotals[0][0] + accidentTotals[0][1];
        int totalMotorbikeAccidents = accidentTotals[0][1] + accidentTotals[1][1] + accidentTotals[2][1];

         
        System.out.print(" ");
        System.out.println("--------------------------------------------------------------"); 
        System.out.println("ROAD ACCIDENT REPORT");
        System.out.println("--------------------------------------------------------------"); 
        System.out.println("                 CAR            MOTOR BIKE");
        System.out.println("Cape Town        " + accidentTotals[0][0] + "            " + accidentTotals[0][1]);
        System.out.println("Johannesburg     " + accidentTotals[1][0] + "            " + accidentTotals[1][1]);
        System.out.println("Port Elizabeth   " + accidentTotals[2][0] + "            " + accidentTotals[2][1]);
        System.out.print("");
        
       
        
        System.out.print("");
        System.out.println("--------------------------------------------------------------");  
        System.out.println("ROAD ACCIDENT TOTALS FOR EACH CITY");
        System.out.println("--------------------------------------------------------------"); 
        
        int totalAccidentsCT = accidentTotals[0][0] + accidentTotals[0][1];
        System.out.println("Cape Town " + totalAccidentsCT);

        int totalAccidentsJB = accidentTotals[1][0] + accidentTotals[1][1];
        System.out.println("Johannesburg " + totalAccidentsJB);

        int totalAccidentsPE = accidentTotals[2][0] + accidentTotals[2][1];
        System.out.println("Port Elizabeth " + totalAccidentsPE);
        
        
        //Calcualting each city to find the highest accident
        String cityWithMostAccidents;
        int highestAccidents;

        if (totalAccidentsCT > totalAccidentsJB && totalAccidentsCT > totalAccidentsPE) {
            cityWithMostAccidents = "Cape Town";
            highestAccidents = totalAccidentsCT;
        } else if (totalAccidentsJB > totalAccidentsCT && totalAccidentsJB > totalAccidentsPE) {
            cityWithMostAccidents = "Johannesburg";
            highestAccidents = totalAccidentsJB;
        } else {
            cityWithMostAccidents = "Port Elizabeth";
            highestAccidents = totalAccidentsPE;
        }

        //Displays the city
        System.out.print("\n");
        System.out.println("CITY WITH THE MOST VEHICLE ACCIDENTS: " +cityWithMostAccidents);
        System.out.print("\n");
        System.out.println("--------------------------------------------------------------");
        
    }
}