package progtest2;

public class RunApplication {

    public static void main(String[] args) {
        //Create an instance of RoadAccidentReport
        RoadAccidentReport accidentDetails = new RoadAccidentReport("Car", "Cape Town", 155);

        
        accidentDetails.printAccidentReport();
    }
}
