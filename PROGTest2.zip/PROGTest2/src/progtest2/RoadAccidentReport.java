
package progtest2;

// Subclass RoadAccidentReport extending RoadAccidents
public class RoadAccidentReport extends RoadAccidents {
    
    public RoadAccidentReport(String VechileType, String CityAccident, int AccidentTotal) {
        super(VechileType, CityAccident, AccidentTotal);
    }

    // Implementing the printAccidentReport method
    public void printAccidentReport() {
        System.out.println("Enter the accident vehicle type: " + VechileType);
        System.out.println("Enter the city for the vehicle accidents: " + CityAccident);
        System.out.println("Enter the total Car accidents for Cape Town: " + AccidentTotal);
        System.out.println(" ");
        System.out.println("VEHICLE ACCIDENT REPORT");
        System.out.println("**************************");
        System.out.println("VEHICLE TYPE: " + VechileType);
        System.out.println("CITY: " + CityAccident);
        System.out.println("ACCIDENT TOTAL: " + AccidentTotal);
        System.out.println("**************************");
    }
}


