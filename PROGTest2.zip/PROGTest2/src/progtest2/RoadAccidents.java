package progtest2;

// Abstract class RoadAccidents
public abstract class RoadAccidents {
    protected String VechileType;
    protected String CityAccident;
    protected int AccidentTotal;

    // Constructor
    public RoadAccidents(String VechileType, String CityAccident, int AccidentTotal) {
        this.VechileType = VechileType;
        this.CityAccident = CityAccident;
        this.AccidentTotal = AccidentTotal;
    }

    // Get methods
    public String getVechileType() {
        return VechileType;
    }

    public String getCityAccident() {
        return CityAccident;
    }

    public int getAccidentTotal() {
        return AccidentTotal;
    }
}


