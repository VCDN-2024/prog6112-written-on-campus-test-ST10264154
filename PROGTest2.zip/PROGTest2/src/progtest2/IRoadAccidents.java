
package progtest2;


public interface IRoadAccidents {
    
    String getAccidentVehicleType();
    String getCity();
    int getAccidentTotal();
    
}
